*****************************************************************************************
*********************************** DESCRIPTION *****************************************
*****************************************************************************************

GrIP is a Mathematica based scientific package that automatizes the computation of
group invariant polynomials. It allows one to construct the complete set of operator 
basis at any given mass dimension. This paves the way to construct the Lagrangian up 
to any mass dimension.

The downloaded file contains 

1. 'GrIP.m' -->This is the main program where all the relevant functions have been
defined, which enables the user to carry out all of the computations.

2. 'GrpInfo.m'--> This file contains information about dimensions of the representations
of various SU(N) groups with N<=5 and their corresponding Dynkin labels.

3. 'MODEL' --> This folder contains examples for model input files.

4. 'Example_SM.nb', 'Example_MSSM.nb'--> Two Mathematica Notebook files, for
non-supersymmetric and supersymmetric input models are provided.

5. 'CHaar.m'--> This sub-program calculates character for a particular representation
and Haar measure for a given connected compact group when the corresponding
Dynkin label is provided.

6. 'Example_CHaar.nb' --> A Mathematica Notebook file that contains illustrative
examples showing how the functions of CHaar work.

*****************************************************************************************
****************************** INSTALLATION GUIDE ***************************************
*****************************************************************************************

The user must perform the following tasks to run the code successfully:

1. Step-1: The user should prepare a model file, if it is not already inside the
'MODEL' folder and keep it inside the 'MODEL' folder which already contains many
example model input files.

2. Step-2: Then load the model file using "Get[]" function in Mathematica by
providing proper $Path to access the model file:
	In[1]:= SetDirectory["<provide address of the MODEL folder>"]
	In[2]:= Get["MODEL/Model.m"]

3. Step-3: Now one has to install the main program. There are two ways to do that:

(a) If the user keeps 'GrIP.m' & 'GrpInfo.m' in a local folder, to load one has to use "Get[]" with
proper address of the main program file as shown in Step-2:
	In[3]:= SetDirectory["<provide address of the package>"]
	In[4]:= Get["GrIP.m"]

(b) If the user keeps 'GrIP.m' & 'GrpInfo.m' in the 'Applications' folder in $UserBaseDirectory, 
the package can be loaded using "Needs[]":
	In[3]:= Needs["GrIP`"]

If the program is loaded correctly, a text cell will appear in 
the Notebook file to notify the user.

*******************************************************************************************
********************************** CONTACT US *********************************************
*******************************************************************************************

For further queries feel free to contact us --> teamgrip.iitk@gmail.com
Thank You!