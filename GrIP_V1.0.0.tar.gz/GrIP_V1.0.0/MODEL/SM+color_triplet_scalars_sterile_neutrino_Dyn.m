(* ::Package:: *)

(***************************************************************************************************************)
	(******                              GrIP modelfile for the Standard Model + color-triplet scalars + Sterile Neutrino                                  ******)
	(******                                                                                                        ******)
	(******          Authors: Upalaparna Banerjee, Joydeep Chakrabortty, Suraj Prakash, Shakeel Ur Rahaman      ******)
	(******                                                                                                        ******)
	(******                       Institutes: Indian Institute of Technology Kanpur, India                         ******)
	(***************************************************************************************************************)


(* ::Section:: *)
(*Information about the Model and Authors*)


(*    Set the version number    *)
GrIP`$GrIPVersion = "V.1.0.0";


(* ::Input::Initialization:: *)
CellPrint[
{Cell[DisplayForm["    GrIP-"<>ToString[GrIP`$GrIPVersion]],"Text",
CellFrame->True,Editable->False,FontFamily->"Lucida Calligraphy",
TextAlignment->Left,FontSize->18],
Cell[
DisplayForm[
"Model Name: SM + color-triplet scalars + Sterile Neutrino\n
Authors: Upalaparna Banerjee, Joydeep Chakrabortty, Suraj Prakash, Shakeel Ur Rahaman \n 
Institutes: Indian Institute of Technology Kanpur, India \n
Emails: upalab, joydeep, surajprk, shakel@iitk.ac.in"],
"Text",CellFrame->True,FontFamily->"Lucida Calligraphy",Editable->False,
Background->White]}];


ModelName="SM+color_triplet_scalars_sterile_nutrino"


(* ::Section:: *)
(*User Input : Symmetry Groups*)


(* ::Input::Initialization:: *)
SymmetryGroupClass={
Group[1]={"GroupName"-> "SU3",
			"N"-> 3
},
Group[2]={"GroupName"-> "SU2",
			"N"-> 2
},
Group[3]={"GroupName"->"U1",
			"N"-> 1
}
};



(* ::Section:: *)
(*User Input : Fields and their properties*)


FieldClass={
Field[1]={
		"FieldName"-> H,
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "SCALAR",
		"Chirality"-> "NA",
		"Baryon Number"-> 0,
		"Lepton Number"-> 0,
		"SU3Dyn"-> {0,0},
		"SU2Dyn"-> {1},
		"U1Dyn"-> 1/2},
Field[2]={
		"FieldName"-> Q,
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "FERMION",
		"Chirality"-> "l",
		"Baryon Number"-> 1/3,
		"Lepton Number"-> 0,
		"SU3Dyn"-> {1,0},
		"SU2Dyn"-> {1},
		"U1Dyn"-> 1/6},
Field[3]={
		"FieldName"-> u,
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "FERMION",
		"Chirality"-> "r",
		"Baryon Number"-> 1/3,
		"Lepton Number"-> 0,
		"SU3Dyn"-> {1,0},
		"SU2Dyn"-> {0},
		"U1Dyn"-> 2/3},
Field[4]={
		"FieldName"-> d,
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "FERMION",
		"Chirality"-> "r",
		"Baryon Number"-> 1/3,
		"Lepton Number"-> 0,
		"SU3Dyn"-> {1,0},
		"SU2Dyn"-> {0},
		"U1Dyn"-> -1/3},
Field[5]={
		"FieldName"-> L,
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "FERMION",
		"Chirality"-> "l",
		"Baryon Number"-> 0,
		"Lepton Number"-> -1,
		"SU3Dyn"-> {0,0},
		"SU2Dyn"-> {1},
		"U1Dyn"-> -1/2},
Field[6]={
		"FieldName"-> el,
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "FERMION",
		"Chirality"-> "r",
		"Baryon Number"-> 0,
		"Lepton Number"-> -1,
		"SU3Dyn"-> {0,0},
		"SU2Dyn"-> {0},
		"U1Dyn"-> -1},
(**********************************************************************************************************EXTENSION*****************************************************************************************)
Field[7]={
		"FieldName"-> \[ScriptCapitalX],
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "SCALAR",
		"Chirality"-> "NA",
		"Baryon Number"-> 1/3,
		"Lepton Number"-> 0,
		"SU3Dyn"-> {1,0},
		"SU2Dyn"-> {0},
		"U1Dyn"-> -1/3},
Field[8]={
		"FieldName"-> \[ScriptCapitalY],
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "SCALAR",
		"Chirality"-> "NA",
		"Baryon Number"-> 2/3,
		"Lepton Number"-> 0,
		"SU3Dyn"-> {0,1},
		"SU2Dyn"-> {0},
		"U1Dyn"-> 1/3},
Field[9]={
		"FieldName"-> \[Psi],
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "FERMION",
		"Chirality"-> "l",
		"Baryon Number"-> 0,
		"Lepton Number"-> 0,
		"SU3Dyn"-> {0,0},
		"SU2Dyn"-> {0},
		"U1Dyn"-> 0}
};




(* ::Section:: *)
(*User Input : Gauge Field tensors and their properties*)


FieldTensorClass={
TensorField[1]={
		"FieldName"-> Bl,
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "VECTOR",
		"Chirality"-> "l",
		"Baryon Number"-> 0,
		"Lepton Number"-> 0,
		"SU3Dyn"-> {0,0},
		"SU2Dyn"-> {0},
		"U1Dyn"-> 0},
TensorField[2]={
		"FieldName"-> Wl,
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "VECTOR",
		"Chirality"-> "l",
		"Baryon Number"-> 0,
		"Lepton Number"-> 0,
		"SU3Dyn"-> {0,0},
		"SU2Dyn"-> {2},
		"U1Dyn"-> 0},
TensorField[3]={
		"FieldName"-> Gl,
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "VECTOR",
		"Chirality"-> "l",
		"Baryon Number"-> 0,
		"Lepton Number"-> 0,
		"SU3Dyn"-> {1,1},
		"SU2Dyn"-> {0},
		"U1Dyn"-> 0}
};
