(* ::Package:: *)

(***************************************************************************************************************)
	(******                              GrIP modelfile for the Standard Model + Dark Matter Candidate Scalar           ******)
	(******                                                                                                        ******)
	(******          Authors: Upalaparna Banerjee, Joydeep Chakrabortty, Suraj Prakash, Shakeel Ur Rahaman      ******)
	(******                                                                                                        ******)
	(******                       Institutes: Indian Institute of Technology Kanpur, India                         ******)
	(***************************************************************************************************************)


(* ::Section:: *)
(*Information about the Model and Authors*)


(*    Set the version number    *)
GrIP`$GrIPVersion = "V.1.0.0";


(* ::Input::Initialization:: *)
CellPrint[
{Cell[DisplayForm["    GrIP-"<>ToString[GrIP`$GrIPVersion]],"Text",
CellFrame->True,Editable->False,FontFamily->"Lucida Calligraphy",
TextAlignment->Left,FontSize->18],
Cell[
DisplayForm[
"Model Name: SM extended by Dark Matter Candidate (Scalar)\n
Authors: Upalaparna Banerjee, Joydeep Chakrabortty, Suraj Prakash, Shakeel Ur Rahaman \n 
Institutes: Indian Institute of Technology Kanpur, India \n
Emails: upalab, joydeep, surajprk, shakel@iitk.ac.in"],
"Text",CellFrame->True,FontFamily->"Lucida Calligraphy",Editable->False,
Background->White]}];


ModelName="BrokenSM_ScalarDM"


(* ::Section:: *)
(*User Input : Symmetry Groups*)


(* ::Input::Initialization:: *)
SymmetryGroupClass={
Group[1]={"GroupName"-> "SU3",
			"N"-> 3
},
Group[2]={"GroupName"->" U1",
			"N"-> 1
}
};



(* ::Section:: *)
(*User Input : Fields and their properties*)


FieldClass={
Field[1]={
		"FieldName"-> Subscript[u, L],
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "FERMION",
		"Chirality"-> "l",
		"Baryon Number"-> 1/3,
		"Lepton Number"-> 0,
		"SU3Dyn"-> {1,0},
		"U1Dyn"-> 2/3
		 },
Field[2]={
		"FieldName"-> Subscript[d, L],
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "FERMION",
		"Chirality"-> "l",
		"Baryon Number"-> 1/3,
		"Lepton Number"-> 0,
		"SU3Dyn"-> {1,0},
		"U1Dyn"-> -1/3
		 },
Field[3]={
		"FieldName"-> Subscript[u, R],
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "FERMION",
		"Chirality"-> "r",
		"Baryon Number"-> 1/3,
		"Lepton Number"-> 0,
		"SU3Dyn"-> {1,0},
		"U1Dyn"-> 2/3
		 },
Field[4]={
		"FieldName"-> Subscript[d, R],
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "FERMION",
		"Chirality"-> "r",
		"Baryon Number"-> 1/3,
		"Lepton Number"-> 0,
		"SU3Dyn"-> {1,0},
		"U1Dyn"-> -1/3
		 },
Field[5]={
		"FieldName"-> Subscript[c, L],
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "FERMION",
		"Chirality"-> "l",
		"Baryon Number"-> 1/3,
		"Lepton Number"-> 0,
		"SU3Dyn"-> {1,0},
		"U1Dyn"-> 2/3
		 },
Field[6]={
		"FieldName"-> Subscript[s, L],
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "FERMION",
		"Chirality"-> "l",
		"Baryon Number"-> 1/3,
		"Lepton Number"-> 0,
		"SU3Dyn"-> {1,0},
		"U1Dyn"-> -1/3
		 },
Field[7]={
		"FieldName"-> Subscript[c, R],
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "FERMION",
		"Chirality"-> "r",
		"Baryon Number"-> 1/3,
		"Lepton Number"-> 0,
		"SU3Dyn"-> {1,0},
		"U1Dyn"-> 2/3
		 },
Field[8]={
		"FieldName"-> Subscript[s, R],
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "FERMION",
		"Chirality"-> "r",
		"Baryon Number"-> 1/3,
		"Lepton Number"-> 0,
		"SU3Dyn"-> {1,0},
		"U1Dyn"-> -1/3
		 },
Field[9]={
		"FieldName"-> Subscript[b, L],
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "FERMION",
		"Chirality"-> "l",
		"Baryon Number"-> 1/3,
		"Lepton Number"-> 0,
		"SU3Dyn"-> {1,0},
		"U1Dyn"-> -1/3
		 },
Field[10]={
		"FieldName"-> Subscript[b, R],
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "FERMION",
		"Chirality"-> "r",
		"Baryon Number"-> 1/3,
		"Lepton Number"-> 0,
		"SU3Dyn"-> {1,0},
		"U1Dyn"-> -1/3
		 },
Field[11]={
		"FieldName"-> Subscript[el, L],
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "FERMION",
		"Chirality"-> "l",
		"Baryon Number"-> 0,
		"Lepton Number"-> -1,
		"SU3Dyn"-> {0,0},
		"U1Dyn"-> -1
		 },
Field[12]={
		"FieldName"-> Subscript[el, R],
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "FERMION",
		"Chirality"-> "r",
		"Baryon Number"-> 0,
		"Lepton Number"-> -1,
		"SU3Dyn"-> {0,0},
		"U1Dyn"-> -1
		 },
Field[13]={
		"FieldName"-> Subscript[\[Nu], eL],
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "FERMION",
		"Chirality"-> "l",
		"Baryon Number"-> 0,
		"Lepton Number"-> -1,
		"SU3Dyn"-> {0,0},
		"U1Dyn"-> 0
		 },
Field[14]={
		"FieldName"-> Subscript[mu, L],
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "FERMION",
		"Chirality"-> "l",
		"Baryon Number"-> 0,
		"Lepton Number"-> -1,
		"SU3Dyn"-> {0,0},
		"U1Dyn"-> -1
		 },
Field[15]={
		"FieldName"-> Subscript[mu, R],
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "FERMION",
		"Chirality"-> "r",
		"Baryon Number"-> 0,
		"Lepton Number"-> -1,
		"SU3Dyn"-> {0,0},
		"U1Dyn"-> -1
		 },
Field[16]={
		"FieldName"-> Subscript[\[Nu], muL],
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "FERMION",
		"Chirality"-> "l",
		"Baryon Number"-> 0,
		"Lepton Number"-> -1,
		"SU3Dyn"-> {0,0},
		"U1Dyn"-> 0
		 },
Field[17]={
		"FieldName"-> Subscript[\[Tau], L],
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "FERMION",
		"Chirality"-> "l",
		"Baryon Number"-> 0,
		"Lepton Number"-> -1,
		"SU3Dyn"-> {0,0},
		"U1Dyn"-> -1
		 },
Field[18]={
		"FieldName"-> Subscript[\[Tau], R],
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "FERMION",
		"Chirality"-> "r",
		"Baryon Number"-> 0,
		"Lepton Number"-> -1,
		"SU3Dyn"-> {0,0},
		"U1Dyn"-> -1
		},
Field[19]={
		"FieldName"-> Subscript[\[Nu], \[Tau]L],
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "FERMION",
		"Chirality"-> "l",
		"Baryon Number"-> 0,
		"Lepton Number"-> -1,
		"SU3Dyn"-> {0,0},
		"U1Dyn"-> 0
		},
		
(***************************************Extension***************************)
Field[20]={
		"FieldName"-> \[Phi],
		"Self-Conjugate"-> True,
		"Lorentz Behaviour"-> "SCALAR",
		"Chirality"-> "NA",
		"Baryon Number"-> 0,
		"Lepton Number"-> 0,
		"SU3Dyn"-> {0,0},
		"U1Dyn"->  0}
};




(* ::Section:: *)
(*User Input : Gauge Field tensors and their properties*)


FieldTensorClass={
TensorField[1]={
		"FieldName"-> Fl,
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "VECTOR",
		"Chirality"-> "l",
		"Baryon Number"-> 0,
		"Lepton Number"-> 0,
		"SU3Dyn"-> {0,0},
		"U1Dyn"-> 0
		 },
TensorField[2]={
		"FieldName"-> Gl,
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "VECTOR",
		"Chirality"-> "l",
		"Baryon Number"-> 0,
		"Lepton Number"-> 0,
		"SU3Dyn"-> {1,1},
		"U1Dyn"-> 0
		 }
};
