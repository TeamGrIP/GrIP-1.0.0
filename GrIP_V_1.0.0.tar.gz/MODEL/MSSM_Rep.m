(* ::Package:: *)

(***************************************************************************************************************)
	(******                              GrIP modelfile for the Minimal Supersymmetric Standard Model               ******)
	(******                                                                                                        ******)
	(******          Authors: Upalaparna Banerjee, Joydeep Chakrabortty, Suraj Prakash, Shakeel Ur Rahaman      ******)
	(******                                                                                                        ******)
	(******                       Institutes: Indian Institute of Technology Kanpur, India                         ******)
	(***************************************************************************************************************)


(* ::Section:: *)
(*Information about the Model and Authors*)


(*    Set the version number    *)
GrIP`$GrIPVersion = "V.1.0.0";


(* ::Input::Initialization:: *)
CellPrint[
{Cell[DisplayForm["    GrIP-"<>ToString[GrIP`$GrIPVersion]],"Text",
CellFrame->True,Editable->False,FontFamily->"Lucida Calligraphy",
TextAlignment->Left,FontSize->18],
Cell[
DisplayForm[
"Model Name: Minimal Supersymmetric Standard Model \n
Authors: Upalaparna Banerjee, Joydeep Chakrabortty, Suraj Prakash, Shakeel Ur Rahaman \n 
Institutes: Indian Institute of Technology Kanpur, India \n
Emails: upalab, joydeep, surajprk, shakel@iitk.ac.in"],
"Text",CellFrame->True,FontFamily->"Lucida Calligraphy",Editable->False,
Background->White]}];


ModelName="MSSM"


(* ::Section:: *)
(*User Input : Symmetry Groups*)


(* ::Input::Initialization:: *)
SymmetryGroupClass={
Group[1]={"GroupName"-> "SU3",
			"N"-> 3
},
Group[2]={"GroupName"-> "SU2",
			"N"-> 2
},
Group[3]={"GroupName"->"U1",
			"N"-> 1
}
};



(* ::Section:: *)
(*User Input : Superfield and their properties*)


SuperFieldClass={
SuperField[1]={
		"FieldName"-> Subscript[\[DoubleStruckCapitalH], \[DoubleStruckU]],
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "SUPERSCALAR",
		"Chirality"-> "NA",
		"Baryon Number"-> 0,
		"Lepton Number"-> 0,
		"SU3Rep"-> "1",
		"SU2Rep"-> "2",
		"U1Rep"-> 1/2},
SuperField[2]={
		"FieldName"-> Subscript[\[DoubleStruckCapitalH], \[DoubleStruckD]],
		"Self-Conjugate"->False,
		"Lorentz Behaviour"-> "SUPERSCALAR",
		"Chirality"-> "NA",
		"Baryon Number"-> 0,
		"Lepton Number"-> 0,
		"SU3Rep"-> "1",
		"SU2Rep"-> "2",
		"U1Rep"-> -1/2},
SuperField[3]={
		"FieldName"-> \[DoubleStruckCapitalQ],
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "SUPERFERMION",
		"Chirality"-> "NA",
		"Baryon Number"-> 1/3,
		"Lepton Number"-> 0,
		"SU3Rep"-> "3",
		"SU2Rep"-> "2",
		"U1Rep"-> 1/6},
SuperField[4]={
		"FieldName"-> \[DoubleStruckCapitalU],
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "SUPERFERMION",
		"Chirality"-> "NA",
		"Baryon Number"-> 1/3,
		"Lepton Number"-> 0,
		"SU3Rep"-> "3 bar",
		"SU2Rep"-> "1",
		"U1Rep"-> -2/3},
SuperField[5]={
		"FieldName"-> \[DoubleStruckCapitalD],
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "SUPERFERMION",
		"Chirality"-> "NA",
		"Baryon Number"-> 1/3,
		"Lepton Number"-> 0,
		"SU3Rep"-> "3 bar",
		"SU2Rep"-> "1",
		"U1Rep"-> 1/3},
SuperField[6]={
		"FieldName"-> \[DoubleStruckCapitalL],
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "SUPERFERMION",
		"Chirality"-> "NA",
		"Baryon Number"-> 0,
		"Lepton Number"-> -1,
		"SU3Rep"-> "1",
		"SU2Rep"-> "2",
		"U1Rep"-> -1/2},
SuperField[7]={
		"FieldName"-> \[DoubleStruckCapitalE],
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "SUPERFERMION",
		"Chirality"-> "NA",
		"Baryon Number"-> 0,
		"Lepton Number"-> -1,
		"SU3Rep"-> "1",
		"SU2Rep"-> "1",
		"U1Rep"-> 1}
};


(* ::Section:: *)
(*User Input : Gauge Field tensors and their properties*)


SuperFieldTensorClass={
TensorSuperField[1]={
		"FieldName"-> \[DoubleStruckCapitalB]l,
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "SUPERVECTOR",
		"Chirality"-> "l",
		"Baryon Number"-> 0,
		"Lepton Number"-> 0,
		"SU3Rep"-> "1",
		"SU2Rep"-> "1",
		"U1Rep"-> 0},
TensorSuperField[2]={
		"FieldName"-> \[DoubleStruckCapitalW]l,
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "SUPERVECTOR",
		"Chirality"-> "l",
		"Baryon Number"-> 0,
		"Lepton Number"-> 0,
		"SU3Rep"-> "1",
		"SU2Rep"-> "3",
		"U1Rep"-> 0},
TensorSuperField[3]={
		"FieldName"-> \[DoubleStruckCapitalG]l,
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "SUPERVECTOR",
		"Chirality"-> "l",
		"Baryon Number"-> 0,
		"Lepton Number"-> 0,
		"SU3Rep"-> "8",
		"SU2Rep"-> "1",
		"U1Rep"-> 0}
};
